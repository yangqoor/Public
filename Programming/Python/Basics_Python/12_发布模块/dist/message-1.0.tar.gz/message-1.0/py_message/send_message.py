def send(text):
    print("正在发送 %s ..." % text)
