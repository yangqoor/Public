def receive():
    return "这是来自 10086 的短信"
