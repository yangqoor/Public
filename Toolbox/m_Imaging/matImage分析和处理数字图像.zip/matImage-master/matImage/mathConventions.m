%MATHCONVENTIONS specifying mathematical conventions for IMAEL m-files
%
% Angles are counted in degrees, unless specified otherwise.
% Many old functions use radians, so it is advised to always handle angle
% data with care.
%
