%LL equivalent of unix alias ll, or ls -lis
%   
%   -----
%
%   author : David Legland 
%   INRA - TPV URPOI - BIA IMASTE
%   created the 02/04/2004.
%
!ls -lis
