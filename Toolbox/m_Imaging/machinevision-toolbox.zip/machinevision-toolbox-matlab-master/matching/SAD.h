void match_SAD_right (unsigned char *left_image, unsigned char *right_image, unsigned char *disparity, double *scores, int width, int height, int window_size, int min_disparity, int max_disparity);
