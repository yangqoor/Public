function NBSRSimParamcb

%NBSRSimParamcb
%
%--------
%Synopsis:
%   NBSRSimParamcb(Parameter)
%
%Description:
%  This is a callback function for the parameters in NBSR simulation block.
%  This callback script is installed in the NBSR simualtion block by
%  first selecting that block in the dbtlinkblocks library and then issueing 
%  the f following command at the Matlab prompt: 
%    set_param(gcb,'MaskCallBacks',{'','','NBSRSimParamcb','','','','','','NBSRSimParamcb',''})
%  See also [2] p. 6-28 -- 6-30.
%
%Output and Input:
%		
%--------
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%  [2]: "Using Simulink, Version 3", The MathWorks, Inc., 1999.
%  [3]: "Writing S-Functions, Version 3", The MathWorks, Inc., 1998.

%
%See Also:
%  dbtlinkblocks.mdl

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
% Start        : 2000-09-xx Svante Bj�rklund (svabj).
% Latest change: $Date: 2000/09/16 09:40:02 $ $Author: svabj $.
% $Revision: 1.1 $
% *****************************************************************************
  

  tempCell=get_param(gcb,'MaskValues');
  targetType=tempCell{3};
  noiseType=tempCell{9};
  set_param(gcb,'MaskEnables',...
    {'on','on','on','on','on','on','on','on','on','on'});

  switch (targetType)
    case 'const'
      maskVisTargetVar = {'on','on','on','on','on'};
    case 'rndn'
      maskVisTargetVar = {'on','on','off','off','on'};
    case 'rndnw'
      maskVisTargetVar = {'on','on','off','off','off'};
    case 'notgt'
      maskVisTargetVar = {'off','off','off','off','off'};
    otherwise
      targetType
      dbterror('Internal error in NSBRSimParamcb: Unkown target type.')
  end; %switch (targetType)

  switch (noiseType)
    case 'rndn'
      maskVisNoiseVar = {'on'};
    case {'rndnw','nonoise'}
      maskVisNoiseVar = {'off'};
    otherwise
      noiseType
      dbterror('Internal error in NSBRSimParamcb: Unkown noise type.')
  end; %switch (noiseType)


  maskVisVar = [{'on','on','on'}, maskVisTargetVar, {'on'}, maskVisNoiseVar];
  set_param(gcb,'MaskVisibilities', maskVisVar);
 
%endfunction NBSRSimParamcb
