%pulseCompressionParamcb
%
% This is a callback function for the signalType (simulated or measured) parameter in the pulse compression block.

tempCell=get_param(gcb,'MaskValues');
signalType=tempCell{1};
set_param(gcb,'MaskEnables',{'on','on'});
if (strcmp(signalType,'simulated') == 1)
  set_param(gcb,'MaskVisibilities',{'on','off'});
elseif (strcmp(signalType,'measured'))
  set_param(gcb,'MaskVisibilities',{'on','on'});
end;
