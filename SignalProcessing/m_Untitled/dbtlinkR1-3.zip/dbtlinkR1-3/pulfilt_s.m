function [sys,x0,str,ts] = pulfilt_s(t,x,u,flag,restParam)

%PULFILT_S S-function for Doppler filtering.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = pulfilt_s(t,x,u,flag,{noOutChan,taperType,nn,r0dB,nbar}) 
%
%Description:
%  Pulse linear filtering (Doppler/slow-time filtering).
%
%   The general form of an M-File S-function syntax is:
%       [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%Output and Input:
%
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Jouni Rantakokko (jounir).
%  Latest change: $Date: 2000/10/15 13:22:53 $ $Author: svabj $.
%  $Revision: 1.4 $
% *****************************************************************************

switch (flag)
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
  case { 1, 2, 4, 9 }
    sys=[];		% Unused flags
  case 3,
    sys=mdlOutputs(t,x,u,restParam);
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

%endfunction pulfilt_s


%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];	% No continuous states
str = []; 	% str is always an empty matrix, reserved for future use
                %  by Simulink
ts  = [0 0];	% initialize the array of sample times

% end mdlInitializeSizes

%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
function sys=mdlOutputs(t,x,u,restParam)

  getinvar
    % Gets the input variable "inVar1" from the previous Simulink block.
    
  taperType = restParam{2};
  if (isempty(restParam{3}))
    sidelobeLevel = 30;
  else
    sidelobeLevel = restParam{3};
  end%if
  if (isempty(restParam{4}))
    noEqSidelobes = 1;
  else
    noEqSidelobes = restParam{4};
  end%if
  sigInSize = sigsize(inVar1);
  noOfCoeff = sigInSize(1);
  if     (strcmp(taperType, 'uniform'))
     taperCoeff=ones(noOfCoeff,1);
  elseif (strcmp(taperType, 'cheby'))
     taperCoeff=chebylp(noOfCoeff,sidelobeLevel);
  elseif (strcmp(taperType, 'taylor') == 1)
     taperCoeff=taylorlp(noOfCoeff,sidelobeLevel,noEqSidelobes);
  elseif (strcmp(taperType, 'bartlett'))
     taperCoeff=bartlett(noOfCoeff);
  elseif (strcmp(taperType, 'blackman'))
     taperCoeff=blackman(noOfCoeff);
  elseif (strcmp(taperType, 'hamming'))
     taperCoeff=hamming(noOfCoeff);
  elseif (strcmp(taperType, 'hanning'))
     taperCoeff=hanning(noOfCoeff);
  elseif (strcmp(taperType, 'kaiser'))
     taperCoeff=kaiser(noOfCoeff);
  elseif (strcmp(taperType, 'triang'))
     taperCoeff=triang(noOfCoeff);
  else
     taperType
     dbterror('Internal error in pulfilt_s: Unkown taper type.')
  end%if
  outVar1 = pulfilt(inVar1,'fft',[],[],[],taperCoeff,[],[],restParam{1});

  putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.

% end mdlOutputs

