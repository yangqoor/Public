DBTLINK An interactive demonstrator of radar array processing.

Help function when writing M-file S-functions:
%  GETPARAMNO Returns a unique positive integer for each call.
%  GETINVAR Gets the input variable "inVar1" from the previous Simulink block.
%  PUTOUTVAR  Puts the output variable "outVar1" to the next Simulink block.
%  PUTOUTVARCLEAR  Clear the variable "inVar1" and puts the output variable 
%    "outVar1" to the next Simulink block.
%  CLEARINVAR  Clears the input variable "inVar1".
