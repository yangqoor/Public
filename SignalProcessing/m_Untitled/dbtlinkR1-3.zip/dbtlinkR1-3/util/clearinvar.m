%CLEARINVAR  Clears the input variables "inVar1", "inVar2" etc...
%
%--------
%Synopsis:
%  clearinvar
%
%Description:
%  This is a MATLAB script that clears the input variable "inVar1".
%
%Input:
%  paramNoIn (IntVectorT): Vector containing numbers which are part of
%    the name of the global variables that are to be cleared. It was
%    created by the function "getinvar".
%
%Output:
%  
%Global Variables:
%  ['pipeVar',num2str(paramNoIn1)] (Arbitrary data type): 
% 
%--------
%Notations:
%  Data type names are shown in parentheses and they start with a capital
%  letter and end with a capital T. Data type definitions can be found in [1]
%  or by "help dbtdata".
%  [D] = This parameter can be omitted and then a default value is used.
%  When the [D]-input parameter is not the last used in the call, it must be
%  given the value [], i.e. an empty matrix.
%  ... = There can be more parameters. They are explained under respective
%  metod or choice.
%
%Examples:
%
%Software Quality:
%  (About what is done to ascertain software quality. What tests are done.)
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:


%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 000110 Svante Bj�rklund (svabj).
%  Latest change: $Date: 2000/10/01 11:52:36 $ $Author: svabj $.
%  $Revision: 1.3 $
% *****************************************************************************


  %noInputs = length(paramNoIn);
  %for i=1:noInputs
  %  eval(['clear global pipeVar',num2str(paramNoIn(i))])
  %end;for i

  %eval(['clear global pipeVar',num2str(paramNoIn1)])

  noInputs = length(u);
  for i=1:noInputs
    eval(['clear global pipeVar',num2str(u(i))])
  end%for i
