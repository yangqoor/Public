Help file for the dbtlink/util file directory.
----------------------------------------------

GETINVAR Gets the input variable "inVar1", "inVar2" etc... from the previous Simulink block.

CLEARINVAR Clears the input variables "inVar1", "inVar2" etc...

GETPARAMNO  Returns a unique positive integer for each call. After the command
  "clear global" the same numbers can be returned again.
  This function is used to in the generation of unique names for global 
  variables.

PUTOUTVAR  Puts the output variable "outVar1" to the next Simulink block without clearing the input variables.

PUTOUTVARCLEAR  Clear the input variables "inVar1", "inVar2" etc... and puts the output variable "outVar1" to the next Simulink block.



GETINVAR3 Gets the input variables "inVar1", "inVar2" and "inVar3" from the previous Simulink blocks. NOTE. obsolete and should not be used any more.

PUTOUTVARCLEAR2  Clear the variables variables corresponding to "inVar1" and "inVar2" and puts the output variable "outVar1" to the next Simulink block.  NOTE. obsolete and should not be used any more.

PUTOUTVARCLEAR3  Clear the global variables corresponding to "inVar1", "inVar2" and "inVar3" and puts the output variable "outVar1" to the next Simulink block.  NOTE. obsolete and should not be used any more.
