function [sys,x0,str,ts] = compsim4_s(t,x,u,flag, waveform, noSamp, tgtType, tgtParam, noiseType, noiseParamIn)

%PULFILT_S S-function for Doppler filtering.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = compsim4_s(t,x,u,flag, waveform, noSamp, tgtType, tgtParam,
%    noiseType, noiseParamIn) 
%
%Description:
%
%   The general form of an M-File S-function syntax is:
%       [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%Output and Input:
%  tgtType (CellArrayT):  {d2r(theta(:)),zeros(size(theta(:),1),1), 
%    SNR(:),d2r(alpha(:)), d2r(dalpha(:)), 
%    ones(size(theta(:),1),1)*Inf,tgtCorrMat}
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Jouni Rantakokko (jounir).
%  Latest change: $Date: 2000/09/16 09:33:51 $ $Author: svabj $.
%  $Revision: 1.2 $
% *****************************************************************************

switch (flag)
   case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;

   case { 1, 2, 4, 9 }
    sys=[];		% Unused flags
  case 3,
    sys=mdlOutputs(t,x,u, waveform, noSamp, tgtType, tgtParam, noiseType, ...
      noiseParamIn);
   otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

%endfunction compsim4_s



%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];	% No continuous states
str = []; 	% str is always an empty matrix, reserved for future use
                %  by Simulink
ts  = [0 0];	% initialize the array of sample times

% end mdlInitializeSizes


%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u, waveform, noSamp, tgtType, tgtParamIn, noiseType, noiseParamIn)

  paramNoIn1 = u;
  eval(['global pipeVar',num2str(paramNoIn1)])
  eval(['inVar1 = pipeVar',num2str(paramNoIn1),';'])

  % tgtParamIn is a cell array.
  noTgt = length(tgtParamIn{1});


%  tgtParamIn (CellArrayT):  {d2r(theta(:)), zeros(size(theta(:),1),1), 
%    SNR(:), d2r(alpha(:)), d2r(dalpha(:)), 
%    ones(size(theta(:),1),1)*Inf, tgtCorrMat}


  alphaDummy = zeros(noTgt,1);
  dalphaDummy = zeros(noTgt,1);
  tgtCorrMatDummy = eye(noTgt);

  switch (tgtType)
    case 'const'
      tgtParamOut = [tgtParamIn{:}];
    case 'rndn'
      tgtParamOut = [tgtParamIn{1:3}, alphaDummy, dalphaDummy, tgtParamIn{6:7}];
    case 'rndnw'
      tgtParamOut = [tgtParamIn{1:3}, alphaDummy, dalphaDummy, tgtParamIn{6}, ...
        tgtCorrMatDummy];
    case 'notgt'
        tgtParamOut = zeros(1,7);	% Dummy values.
    otherwise
      tgtType
      dbterror('Internal error in compsim4_s: Unkown target type.')
  end; %switch (tgtType)
  

  switch (noiseType)
    case 'rndn'
      noiseParamOut = noiseParamIn;
    case {'rndnw','nonoise'}
      noiseParamOut = [];
    otherwise
      noiseType
      dbterror('Internal error in compsim4_s: Unkown noise type.')
  end; %switch (noiseType)
  

  outVar1 = compsim4(inVar1, waveform, noSamp, tgtType, tgtParamOut, ...
    noiseType,   noiseParamOut);
 
  eval(['clear global pipeVar',num2str(paramNoIn1)])

  paramNoOut1 = getparamno;
  eval(['global pipeVar',num2str(paramNoOut1)])
  eval(['pipeVar',num2str(paramNoOut1),' = outVar1;'])
  sys = paramNoOut1;

% end mdlOutputs

