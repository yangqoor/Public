function [sys,x0,str,ts] = defant_s2(t,x,u,flag,whereElement,restParam)

%DEFANT_S2 S-function for antenna definition.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = pantpat3_s(t,x,u,flag,restParam) 
%
%Description:
%  S-function for antenna definition.
%
%  The general form of an M-File S-function syntax is:
%    [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%  Optional parameters, P1,...,Pn can be provided to the S-function and
%  used during any FLAG operation.
%
%Output and Input:
%  whereElement (IntScalarT): Position for the antenna element input parameter to the function "defan". 
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx NN NN (aaaa).
%  Latest change: $Date: 2000/09/16 09:34:27 $ $Author: svabj $.
%  $Revision: 1.3 $
% *****************************************************************************

switch flag,
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
  case 3,
    sys=mdlOutputs(t,x,u, whereElement, restParam);
  case {1, 2, 4, 9}
     sys=[];	% Unused flags
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end%switch

%endfunction defant_s2

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];

% end mdlInitializeSizes



%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================

function sys=mdlOutputs(t,x,u,whereElement,restParam)

% This S-function ... 

  getinvar
    % Gets the input variable "inVar1" from the previous Simulink block.
    % "inVar1" contains the antenna element definition.

  outVar1 = defant(restParam{1:whereElement-1}, inVar1, ...
    restParam{whereElement+1:end});

  putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.
    % "outVar1" contains the antenna definition.
% end mdlOutputs
