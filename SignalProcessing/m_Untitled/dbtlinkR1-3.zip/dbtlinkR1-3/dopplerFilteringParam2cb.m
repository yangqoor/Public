%dopplerFilteringParam2cb
%
%--------
%Synopsis:
% 
%Description:
%  This is a callback function for the taperType parameter in the pulse 
%  compression block.
%  This callback script is installed in the doppler filtering block by
%  first selecting that block in the dbtlinkblocks library and then issueing 
%  the f following command at the Matlab prompt: 
%    set_param(gcb,'MaskCallBacks',{'','dopplerFilteringParam2cb','',''})
%  See also [2] p. 6-28 -- 6-30.
%
%Output and Input:
%		
%--------
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%  [2]: "Using Simulink, Version 3", The MathWorks, Inc., 1999.
%  [3]: "Writing S-Functions, Version 3", The MathWorks, Inc., 1998.

%
%See Also:
%  dbtlinkblocks.mdl

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
% Start        : 2000-01-xx Jouni Rantakokko (jounir).
% Latest change: $Date: 2000/09/16 09:34:39 $ $Author: svabj $.
% $Revision: 1.2 $
% *****************************************************************************
  

tempCell=get_param(gcb,'MaskValues');
taperType=tempCell{2};
set_param(gcb,'MaskEnables',{'on','on','on','on'});

switch(taperType)
   case 'cheby'
      set_param(gcb,'MaskVisibilities',{'on','on','on','off'});
   case 'taylor'
      set_param(gcb,'MaskVisibilities',{'on','on','on','on'});
   case {'bartlett','blackman','hamming','hanning','kaiser','triang'}
      set_param(gcb,'MaskVisibilities',{'on','on','off','off'});   
end;	%switch
