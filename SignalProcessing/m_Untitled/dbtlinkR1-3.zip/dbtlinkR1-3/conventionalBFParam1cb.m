%conventionalBFParam1cb
%
% This is a callback function for the first parameter in the conventional beamforming block.
% Disable the parameter field for taperParam if taperType is chosen to 'uniform'
tempCell=get_param(gcb,'MaskValues');
taperType=tempCell{4};
set_param(gcb,'MaskEnables',{'on','on','on','on','on','on'});

switch(taperType)
   
   case 'uniform'
   		set_param(gcb,'MaskVisibilities',{'on','on','on','on','off','off'});
	case 'cheby'
   		set_param(gcb,'MaskVisibilities',{'on','on','on','on','on','off'});
	case 'taylor'
   		set_param(gcb,'MaskVisibilities',{'on','on','on','on','on','on'});      
         
end %switch
   