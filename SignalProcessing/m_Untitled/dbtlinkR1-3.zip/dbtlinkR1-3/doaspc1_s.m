function [sys,x0,str,ts] = doaspc1_s(t,x,u,flag,method,restParam)

%DOASPC1_S  S-function for spectral DOA estimation.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = pulfilt_s(t,x,u,flag,{noOutChan,taperType,nn,r0dB,nbar}) 
%
%Description:
%   S-function for spectral DOA estimation.
%
%   The general form of an M-File S-function syntax is:
%       [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%Output and Input:
%
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Jouni Rantakokko (jounir).
%  Latest change: $Date: 2000/10/04 16:30:27 $ $Author: svabj $.
%  $Revision: 1.3 $
% *****************************************************************************

switch flag,
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
  case { 1, 2, 4, 9 }
    sys=[];		% Unused flags
  case 3,
    sys=mdlOutputs(t,x,u,method,restParam);
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end%switch

%endfunction doaspc1_s



%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      =-1;		% DYNAMICALLY SIZED INPUT PORT WIDTH
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];		% No continuous states
str = []; 	% str is always an empty matrix, reserved for future use by Simulink
ts  = [0 0];	% initialize the array of sample times

%endfunction mdlInitializeSizes



%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
function sys=mdlOutputs(t,x,u,method,restParam)

  %getinvar
    % Gets the input variable "inVar1" from the previous Simulink block.
  %outVar1 = doaspc1(method,inVar1,[],smplPoints,[],rangeIx,cpiIx);
    % Calculate the DOA spectrum by a DBT function.
  %putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.
    
  smplPoints = restParam{1};
  rangeIx = restParam{2};
  cpiIx = restParam{3};

  getinvar

  if (length(u) == 2)
    % Detection method estimated the number of sources: (noSrc=u(2)).
    restParam{4} = inVar2; 
  end;	

  if (strcmp(method,'music') == 1)
    noSrc = restParam{4};
    tmpVar1 = doaspc1(method,inVar1,[],smplPoints,[],rangeIx,cpiIx,noSrc);
  elseif (strcmp(method,'minnorm') == 1)
    noSrc = restParam{4};
    tmpVar1 = doaspc1(method,inVar1,[],smplPoints,[],rangeIx,cpiIx,noSrc);
  elseif (strcmp(method,'cbf') == 1)
    taperType = restParam{4};
    taperParam = restParam{5};
    tmpVar1 = doaspc1(method, inVar1, [], smplPoints, [], rangeIx, cpiIx, ...
      taperType, taperParam);   
  else
    tmpVar1 = doaspc1(method,inVar1,[],smplPoints,[],rangeIx,cpiIx);
  end;

  outVar1 = doaspc2sig(tmpVar1,1);
  
  putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.

    
%endfunction mdlOutputs
