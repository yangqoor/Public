function [sys,x0,str,ts] = datachoice_s(t,x,u,flag,restParam)

%DATACHOICE_S S-function for data selection.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = compsim4_s(t,x,u,flag, waveform, noSamp, tgtType, tgtParam,
%    noiseType, noiseParamIn) 
%
%Description:
%  Select data snapshots from the radar signal and estimate the DOA
%  correlation matrix on the chosen data. Pulse, range and cpi index
%  should be in the form 1:24 if elements 1 to 24 are desired. All
%  elements of the corresponding parameter are selected by typing ':'.
%  See help text of function "basecorrm" for more information.
%
%  The general form of an M-File S-function syntax is:
%    [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%  Optional parameters, P1,...,Pn can be provided to the S-function and
%  used during any FLAG operation.
%
%Output and Input:
%  restParam (CellArrayT): {pulseIx,rangeIx,cpiIx}
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Svante Bj�rklund (svabj).
%  Latest change: $Date: 2000/09/16 09:33:24 $ $Author: svabj $.
%  $Revision: 1.4 $
% *****************************************************************************


switch flag,

  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;

  case { 1, 2, 4, 9 }
    sys=[];		% Unused flags

  case 3,
    sys=mdlOutputs(t,x,u,restParam);

  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];		% No continuous states
str = []; 	% str is always an empty matrix, reserved for future use by Simulink
ts  = [0 0];	% initialize the array of sample times

% end mdlInitializeSizes

%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
function sys=mdlOutputs(t,x,u,restParam)

%  restParam (CellArrayT): {pulseIx,rangeIx,cpiIx}

  getinvar
    % Gets the input variable "inVar1" from the previous Simulink block.

  outVar1 = [];
  for pulseLoop = restParam{1}
     for rangeLoop = restParam{2}
        for cpiLoop = restParam{3}
           outVar1 = [ outVar1, getm3(inVar1.signals,3,[],pulseLoop,...
             rangeLoop, ':',1,cpiLoop) ];
        end;
     end;
  end;   
    % Extracts the desired elements (snapshots) from the data.
  %disp('datachoice_s: size(outVar1)'),size(outVar1)

  putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.

% end mdlOutputs

