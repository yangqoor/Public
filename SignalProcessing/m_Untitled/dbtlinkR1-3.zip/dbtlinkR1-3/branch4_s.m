function [sys,x0,str,ts] = branch4_s(t,x,u,flag)
% function [sys,x0,str,ts] = branch4_s(t,x,u,flag)
% 
% The input port signal is duplicated and put out on all output ports of this block.
% Input: Arbitrary input (typically a radar signal). The input is a (in dbtlink)
% global variable name that contains the true input. (See getinvar and putoutvar for more info)
% Output: The input signal exists on all output ports.
%

switch flag,

  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;

  case 1,
    sys=mdlDerivatives(t,x,u);

  case 2,
    sys=mdlUpdate(t,x,u);

  case 3,
    sys=mdlOutputs(t,x,u);

  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  case 9,
    sys=mdlTerminate(t,x,u);

  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

% end branch_s

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

% initialize the initial conditions
x0  = [];

% str is always an empty matrix
str = [];

% initialize the array of sample times
ts  = [0 0];

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)

sys = [];

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

  paramNoIn1 = u;
  eval(['global pipeVar',num2str(paramNoIn1)])
  eval(['inVar1 = pipeVar',num2str(paramNoIn1),';'])

  eval(['clear global pipeVar',num2str(paramNoIn1)])
    % This is unnecessary if the input global variable is used as one
    % of the output global variables.

  paramNoOut1 = getparamno;
  eval(['global pipeVar',num2str(paramNoOut1)])
  eval(['pipeVar',num2str(paramNoOut1),' = inVar1;'])
  sys(1) = paramNoOut1;
  
  paramNoOut2 = getparamno;
  eval(['global pipeVar',num2str(paramNoOut2)])
  eval(['pipeVar',num2str(paramNoOut2),' = inVar1;'])
  sys(2) = paramNoOut2;
  
  paramNoOut3 = getparamno;
  eval(['global pipeVar',num2str(paramNoOut3)])
  eval(['pipeVar',num2str(paramNoOut3),' = inVar1;'])
  sys(3) = paramNoOut3;
  
  paramNoOut4 = getparamno;
  eval(['global pipeVar',num2str(paramNoOut4)])
  eval(['pipeVar',num2str(paramNoOut4),' = inVar1;'])
  sys(4) = paramNoOut4;
  
  % end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
