function [sys,x0,str,ts] = pantpat3_s(t,x,u,flag, guiTypes, restParam)

%PANTPAT3_S S-function for antenna pattern plot.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = pantpat3_s(t,x,u,flag,restParam) 
%
%Description:
%  S-function for antenna pattern plot.
%
%  The general form of an M-File S-function syntax is:
%    [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%  Optional parameters, P1,...,Pn can be provided to the S-function and
%  used during any FLAG operation.
%
%Output and Input:
%  guiTypes (CellArrayT): 
%    {beamType, taperType, adaptType, modelErrorSrc, figureType, plotType, 
%    plotTitle}
%  adaptType (StringT):
%  restParam (CellArrayT):  
%    {mainPointDoa,subPointDoa,antError,taperType,taperParam,iNCorrMat,
%    smplPoints,lambda,sigType,sigPart,minValuedB,scaleType,normType,
%    plotTypeplotOpt,extra1}
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Jouni Rantakokko (jounir).
%  Latest change: $Date: 2000/10/04 15:58:33 $ $Author: svabj $.
%  $Revision: 1.7 $
% *****************************************************************************

switch flag,

  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes(guiTypes);

  case { 1, 2, 4, 9 }
    sys=[];		% Unused flags

  case 3,
    sys=mdlOutputs(t,x,u, guiTypes, restParam);

  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes(guiTypes)

  adaptType = guiTypes{3};
  switch (adaptType)
  case {'not adaptive', 'adaptive parameter'}
    numInputs = 1;
  case 'adaptive inport'
    numInputs = 2;
  otherwise
      adaptType
      dbterror('Internal error in pantpat3_s: Unkown target type.')
  end%switch

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

  sizes = simsizes;
  sizes.NumContStates  = 0;
  sizes.NumDiscStates  = 0;
  sizes.NumOutputs     = 0;
  sizes.NumInputs      = numInputs;
  sizes.DirFeedthrough = 1;
  sizes.NumSampleTimes = 1;   % at least one sample time is needed

  sys = simsizes(sizes);
  x0  = [];		% No continuous states
  str = []; 	% str is always an empty matrix, reserved for future use by 
                %  Simulink
  ts  = [0 0];	% initialize the array of sample times

  maskVisVar = {'on','on','on','on','on',...
                'on','on','on','on','on',...
                'on','on','on','off','off',...
                'on','off','off','on','on',...
                'on','on'};
  set_param(gcb,'MaskVisibilities', maskVisVar);

  % end mdlInitializeSizes


%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
function sys=mdlOutputs(t,x,u, guiTypes, restParam)

  getinvar
    % Gets the input variable "inVar1" from the previous Simulink block.

  beamType = guiTypes{1};
  adaptType = guiTypes{3};
  figureType = guiTypes{5};
  plotTitle = guiTypes{7};


  mainPointDoa = restParam{1};
    % If "mainPointDoa" is a matrix it contains main beam pointing directions.
    % If "mainPointDoa" is a cell array it contains beamforming weights.
   
  switch (beamType)
  case 'directions'
    % Forming beams to specified direction 
    if (~chkdtyph(inVar1,'AntDefT'))
      % Do nothing with "restParam".
      antennaIn = inVar1;
    else
      dbterror('Invalid inport data type for beamType = "directions".')
    end%if
  case 'weights'
    % Using ready made weights to form the antenna pattern.
    if (~chkdtyph(inVar1,'AntDefT'))
      % If "inVar1" is of type 'AntDefT'.
      weights = mainPointDoa;
      antennaIn = inVar1;
    elseif (~chkdtyph(inVar1,'RxRadarSigT'))
      % If "inVar1" is of type 'RxRadarSigT'.
      weights = inVar1.antenna.beamSpaceTrans;
      antennaIn = inVar1.antenna.element;
        % Using the "element" field because must pass the last beamforming 
        % performed.
    else
      dbterror('Invalid inport data type.')
    end%if
    restParam = {{weights}, restParam{2:end}};
  otherwise
    beamType
    dbterror('Internal error in pantpat3_s: Unkown beamType.')
  end%switch

  switch (adaptType)
    case {'not adaptive', 'adaptive parameter'}
      restParamOut= restParam;
    case 'adaptive inport'
      if (length(u) ~= 2)
        dbterror(['Wrong number of inports for "adaptive inport". '],...
          ['Use a 2-mux to input both an antenna deinition (1st input) '],...
          ['and a interference correlation matrix (2nd input).'])
      end%if
      INCorrMat = inVar2;
      restParamOut= {restParam{1:5},INCorrMat,restParam{7:end}};
    otherwise
      adaptType
      dbterror('Internal error in pantpat3_s: Unkown adaptType.')
  end%switch

  switch (figureType)
  case {'non-GUI'}
    figure
    pantpat3(antennaIn,restParamOut{:});
  case 'GUI'
    disp('pantpat3_s: plotType GUI')
  otherwise
      adaptType
      dbterror('Internal error in pantpat3_s: Unkown target type.')
  end%switch
  title(plotTitle)

  clearinvar
    % Clears all inport variables.

  sys = [];

% end mdlOutputs

