function versionNo = dbtlinkversion(dispOpt)

%DBTLinkVERSION Prints on the screen or returns the number of this release of DBTLink.
%
%--------
%Synopsis:
%
%  versionNo = dbtlinkversion(dispOpt)
%
%Description:
%  Prints on the screen or returns the version number of this release of DBTLink.
%
%Output and Input:
%  versionNo (StringT): The version number of this release of DBTLink.
%  dispOpt [D](StringT): Display options.
%    = 'n': Don't print on screen.
%    = 'p': Print on screen.
%
%--------
%Notations:
%  Data type names are shown in parentheses and they start with a capital
%  letter and end with a capital T. Data type definitions can be found in [1]
%  or by "help dbtdata".
%  [D] = This parameter can be omitted and then a default value is used.
%  When the [D]-input parameter is not the last used in the call, it must be
%  given the value [], i.e. an empty matrix.
%  ... = There can be more parameters. They are explained under respective
%  metod or choice.
%
%References:
%
%See Also:



% *****************************************************************************
%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-2000. See the file dbtright.m for copyright notice.
%
%  Start        : 990314 Svante Bj�rklund (svabj).
%  Latest change: $Date: 2000/10/16 16:31:36 $ $Author: svabj $.
%  $Revision: 1.1 $
% *****************************************************************************

% ----------------------------------------------------------------------- %
% The version number constant.
%
% This constant must be changed just before tagging a new release in DBT.
% ----------------------------------------------------------------------- %

%verNoVar = 'R2-18';


% ----------------------------------------------------------------------- %
% Handle input parameters.
% ----------------------------------------------------------------------- %

if (nargin < 0)
  error('DBT-Error: To few input parameters.')
end

% ****************** Add missing input parameters ******************

if (nargin < 1)
  dispOpt = [];
end

% ****************** Default values ******************

if isempty(dispOpt)
  dispOpt = '-';
end%if

% ****************** Error check input parameters ******************


% ----------------------------------------------------------------------- %
% Do the work.
% ----------------------------------------------------------------------- %

versionFile = 'dbtlinkver.txt';
if (exist(versionFile) == 2)
  fid=fopen(versionFile);
  verNoVar = fgetl(fid);
  fclose(fid);
else
  dbterror(['Version file', versionFile,' does not exist.'])
end%if


if ((((nargout > 0) & (dispOpt == 'p')))| ((nargout == 0) & (dispOpt ~= 'n')))
  fprintf('DBT, A Matlab Toolbox for Radar Signal Processing, Release %s\n',verNoVar)
end%if

% ****************** Output parameters ******************

if (nargout > 0)
    versionNo = verNoVar;
end%if
