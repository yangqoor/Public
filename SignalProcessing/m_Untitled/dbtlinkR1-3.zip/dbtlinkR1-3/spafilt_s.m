function [sys,x0,str,ts] = spafilt_s(t,x,u,flag,method,restParam)

%SPAFILT_S S-function for beamforming.
%
%--------
%Synopsis:
%  [sys,x0,str,ts] = [sys,x0,str,ts] = spafilt_s(t,x,u,flag,method,restParam) 
%
%Description:
%  Pulse linear filtering (Doppler/slow-time filtering).
%
%   The general form of an M-File S-function syntax is:
%       [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%Output and Input:
%  method (): Beamforming method.
%    'cbf':
%    'acbf':
%    'capon':
%  restParam (): { d2r(subArrayPoint), d2r(beamChoice), orthBeamFlag, 
%    {taperType, taperParam, nbar} } :
%
%Known Bugs:
%
%References:
%  [1]: Bj�rklund S.: "DBT, A MATLAB Toolbox for Radar Signal Processing.
%    Reference Guide", FOA-D--9x-00xxx-408--SE, To be published.
%
%See Also:
%  

%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-99. See the file dbtright.m for copyright notice.
%
%  Start        : 0001xx Jouni Rantakokko (jounir).
%  Latest change: $Date: 2000/10/01 10:49:06 $ $Author: svabj $.
%  $Revision: 1.9 $
% *****************************************************************************


switch flag,

  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;

  case { 1, 2, 4, 9 }
    sys=[];		% Unused flags

  case 3,
    sys=mdlOutputs(t,x,u,method,restParam);

  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      =-1;   % Dynamically sized input porth width
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

x0  = [];		% No continuous states
str = []; 	% str is always an empty matrix, reserved for future use by Simulink
ts  = [0 0];	% initialize the array of sample times

% end mdlInitializeSizes

%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
function sys=mdlOutputs(t,x,u,method,restParam)

  getinvar
  % Gets the input variable "inVar1" from the previous Simulink block.
  if (strcmp(method,'cbf') == 1)
     taperVariables = restParam{4};
     taperCoeff=gettap1(inVar1.antenna,taperVariables{:});
     outVar1 = spafilt(inVar1,method,[],{restParam{1},[]},restParam{2},...
       taperCoeff,[],[],[],restParam{3});
  elseif(strcmp(method,'capon') == 1)
     outVar1 = spafilt(inVar1,method,[],{restParam{1},[]},restParam{2});
  elseif (strcmp(method,'acbf') == 1)
     taperVariables = restParam{4};
     taperCoeff=gettap1(inVar1.antenna,taperVariables{:});
     outVar1 = spafilt(inVar1,method,[],{restParam{1},[]},restParam{2},...
       taperCoeff,inVar2,restParam{3});
  end%if
  putoutvarclear
    % Clear the variable "inVar1" and puts the output variable "outVar1"
    % to the next Simulink block.

% end mdlOutputs
