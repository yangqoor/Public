function [steer]=monopulse_vec(lamda,array_pre,ds,alpha_out,target_par0,ff,a_mean,a_var,state_input)
%%�����������²�������һά������ɵġ�
if state_input==1
    ay=target_par0(5);
    az=target_par0(6);
else
    ay=target_par0(7);
    az=target_par0(8);
end

[steer_l Gl pl]=Gen_st_vector_cs(lamda,array_pre,ds,alpha_out(1,1),az,ff,a_mean,a_var);
[steer_r Gr pr]=Gen_st_vector_cs(lamda,array_pre,ds,alpha_out(1,2),az,ff,a_mean,a_var);
[steer_sy Gs ps]=Gen_st_vector_cs(lamda,array_pre,ds,alpha_out(1,3),az,ff,a_mean,a_var);

[steer_u Gl pl]=Gen_st_vector_cs(lamda,array_pre,ds,ay,alpha_out(2,1),ff,a_mean,a_var);
[steer_d Gr pr]=Gen_st_vector_cs(lamda,array_pre,ds,ay,alpha_out(2,2),ff,a_mean,a_var);
[steer_sz Gs ps]=Gen_st_vector_cs(lamda,array_pre,ds,ay,alpha_out(2,3),ff,a_mean,a_var);

steer=[steer_l,steer_r,steer_sy,steer_u,steer_d,steer_sz];