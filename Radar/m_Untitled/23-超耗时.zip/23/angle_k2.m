function [k]=angle_k2(alpha_in,lamda,ds)
alphay_l=alpha_in(1,1);
alphay_r=alpha_in(1,2);
alphay_s=alpha_in(1,3);
alphaz_l=alpha_in(2,1);
alphaz_r=alpha_in(2,2);
alphaz_s=alpha_in(2,3);
dsy=ds(1,:);
dsz=ds(2,:);
ky=angle_k(alphay_l,alphay_r,alphay_s,alphaz_s,lamda,1,dsz,dsy);
kz=angle_k(alphaz_l,alphaz_r,alphaz_s,alphay_s,lamda,0,dsz,dsy);
k=[ky,kz];
% N=10000;
% alphay_scan=linspace(alphay_l,alphay_r,N);
% errory_cos=cosd(alphay_scan)-cosd(alphay_s);
% alphaz_scan=linspace(alphaz_l,alphaz_r,N);
% errorz_cos=cosd(alphaz_scan)-cosd(alphaz_s);
% for m=1:3
%     alphay_st=exp(j*2*pi/lamda*(dsy*cosd(alpha_in(1,m))+dsz*cosd(alphaz_s)));
%     for n=1:N
%         alphay_scan_st=exp(j*2*pi/lamda*(dsy*cosd(alphay_scan(n))+dsz*cosd(alphaz_s)));
%         Fy(m,n)=conj(alphay_scan_st)*alphay_st.';
%     end
% end
% ratey=(abs(Fy(1,:))-abs(Fy(2,:)))./abs(Fy(3,:));
% py=polyfit(errory_cos,ratey,1);
% ky=py(1);
% for m=1:3
%     alphaz_st=exp(j*2*pi/lamda*(dsy*cosd(alphay_s)+dsz*cosd(alpha_in(2,m))));
%     for n=1:N
%         alphaz_scan_st=exp(j*2*pi/lamda*(dsy*cosd(alphay_s)+dsz*cosd(alphaz_scan(n))));
%         Fz(m,n)=conj(alphaz_scan_st)*alphaz_st.';
%     end
% end
% ratez=(abs(Fz(1,:))-abs(Fz(2,:)))./abs(Fz(3,:));
% pz=polyfit(errorz_cos,ratez,1);
% kz=pz(1);
% k=[ky,kz];