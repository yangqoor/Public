#ifdef ENABLE_GPU
#error "The file nnsubsample.cu should be compiled instead"
#endif
#include "nnsubsample.cu"

