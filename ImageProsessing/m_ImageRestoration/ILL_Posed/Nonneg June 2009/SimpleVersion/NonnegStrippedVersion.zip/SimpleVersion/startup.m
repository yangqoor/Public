%  startup.m
%
%  Append subdirectories to MATLAB path.

  path(path,'CostFunction');
  path(path,'Optimizer');
  path(path,'Setup');
  path(path,'Deblurring');
  
