# LLE
Largest Lyapunov Exponent;

Lyapunov exponent spectrum.
