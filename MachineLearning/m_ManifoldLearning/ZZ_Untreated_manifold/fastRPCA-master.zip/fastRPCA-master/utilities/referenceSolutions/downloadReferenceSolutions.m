% Run this script to download the reference files
% (117 MB)

disp('Downloading 117 MB file of reference solutions');
unzip(...
    'http://amath.colorado.edu/faculty/becker/code/referenceSolutions_v1.0.zip');

