function setup_fastRPCA
% SETUP_FASTRPCA Adds the fastRPCA toolbox to the path

baseDirectory = fileparts(mfilename('fullpath'));
addpath(genpath(baseDirectory));
