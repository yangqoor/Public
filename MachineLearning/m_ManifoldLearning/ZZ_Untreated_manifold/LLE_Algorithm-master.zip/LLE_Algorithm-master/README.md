# LLE_Algorithm
locally linear embedding algorithm code write by matlab, just a little update download from http://www.cs.nyu.edu/~roweis/lle/code.html
