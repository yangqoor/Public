# Principal_component_transform_PCA_PCT
Dimensionality reduction of images.
In this project MATLAB has been used to do PCA on multispectral or hyperspectral images without using any inbuilt functions.
