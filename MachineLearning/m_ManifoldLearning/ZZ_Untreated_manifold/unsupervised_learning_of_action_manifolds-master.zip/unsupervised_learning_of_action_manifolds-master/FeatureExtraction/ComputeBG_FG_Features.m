% Compute Background and Foreground Features
ExtractFeaturesFromForeground_CornerPoints;
fprintf('Finished computing foreground features\n');

ExtractFeaturesFromBackground_CornerPoints;
fprintf('Finished computing background features\n');