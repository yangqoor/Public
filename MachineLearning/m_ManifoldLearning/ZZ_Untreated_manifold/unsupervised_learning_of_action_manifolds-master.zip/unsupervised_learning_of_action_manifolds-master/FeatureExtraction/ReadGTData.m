% Reading the grounth truth data from VIPER GT
