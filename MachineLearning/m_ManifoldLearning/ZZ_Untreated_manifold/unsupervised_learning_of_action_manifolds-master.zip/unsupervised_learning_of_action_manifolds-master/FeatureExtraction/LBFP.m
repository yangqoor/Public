% To compute Local Binary Flow Pattern between subregions
function L = LBFP(img_mag,img_dir)

% Find the dominant orient matrix


end