# MDS-of-National-Parks
Given animal species data from 56 national parks in the U.S., calculated distances between each park indicating their similarities in Matlab and created a two-dimensional representation of the distances in R to analyze the mathematical model.
