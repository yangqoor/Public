# isomap
IsoMap algorithm in MATLAB, with crappy Floyd-Warshall for all pairs shortest distances.
Used for the face/nonface training set.
![image](train_set_32.jpg)
